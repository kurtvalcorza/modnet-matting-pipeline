"""Probes for the Notebook Review Framework v1 review of tutorials/modnet_matting_colab.ipynb.

Reviewed revision: kurtvalcorza/modnet-matting-pipeline @ d74036be500995a26caa29083c192445689fc1b4
(notebook blob ab5bea5843e2665a7f5b5600c43fe4cf4c9a7be5, the blob of the recorded Kaggle T4 run of 2026-09-20).

Direct execution is LOCAL CPU ONLY (CUDA_VISIBLE_DEVICES="", OMP_NUM_THREADS=4) in the build venv `dimer-next16`
(Python 3.12.10, torch 2.14.0+cu130, numpy 2.5.3, pillow 11.3.0, safetensors 0.8.0 = PINS; huggingface-hub 0.36.2
instead of the pinned 1.32.0). The install cell runs with the notebook's own DIMER_NOTEBOOK_CI_PREINSTALLED=1 switch,
so nothing is installed. HF_HOME and the working directory are empty scratch directories, so the checkpoint is
fetched from the Hub at the pinned revision, audited and converted fresh. `google.colab.files.upload` is a shim that
returns prepared bytes. It is NOT a Colab run.

Usage: python run_probes.py <worktree> <scratch_dir> <phase>
  phase static  : P1 static checks, P5 BYOD split/minimum arithmetic (no model)
  phase default : P2 default Run all (cells 3..23), P4 exercise rerun of Section 6 (TRAINABLE='full', EPOCHS=1),
                  P3 rerun from Section 4 as the BYOD instruction says (stale 'frozen' model)
  phase byod    : P6 BYOD zip of 6 pairs + own photograph through cells 15..23 after a fresh Section 3
Results are merged into results.json next to this script; source_manifest.json is written by every phase.
"""
import contextlib
import hashlib
import io
import json
import os
import subprocess
import sys
import time
import traceback
import types
import zipfile

WT, SCRATCH, PHASE = sys.argv[1], sys.argv[2], sys.argv[3]
HERE = os.path.dirname(os.path.abspath(__file__))
NB_PATH = os.path.join(WT, 'tutorials', 'modnet_matting_colab.ipynb')
os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = ''
os.environ['HF_HOME'] = os.path.join(SCRATCH, 'hf_home')
os.environ['HF_HUB_DISABLE_PROGRESS_BARS'] = '1'
os.environ.setdefault('OMP_NUM_THREADS', '4')
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.makedirs(SCRATCH, exist_ok=True)

RES_PATH = os.path.join(HERE, 'results.json')
RESULTS = json.load(open(RES_PATH, encoding='utf-8')) if os.path.exists(RES_PATH) else {}


def save():
    with open(RES_PATH, 'w', encoding='utf-8') as fh:
        json.dump(RESULTS, fh, indent=1, default=str)


def sha256_file(path):
    with open(path, 'rb') as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def git(*args):
    return subprocess.run(['git', '-C', WT, *args], capture_output=True, text=True).stdout.strip()


SOURCES = ['tutorials/modnet_matting_colab.ipynb', 'tutorials/README.md', 'docs/release-verification.md', 'STATUS.md',
           'README.md', 'tools/build_notebook.py', 'tools/notebook_template.py', 'tools/validate_release_assets.py',
           'src/modnet_matting_pipeline/pipeline.py', 'src/modnet_matting_pipeline/samples.py',
           'src/modnet_matting_pipeline/metrics.py', 'src/modnet_matting_pipeline/modeling.py', 'pyproject.toml']
with open(os.path.join(HERE, 'source_manifest.json'), 'w', encoding='utf-8') as fh:
    json.dump({'revision': git('rev-parse', 'HEAD'), 'files': {p: sha256_file(os.path.join(WT, p)) for p in SOURCES}}, fh, indent=1)

NB = json.load(open(NB_PATH, encoding='utf-8'))
CELLS = NB['cells']
SRC = {i: ''.join(c['source']) for i, c in enumerate(CELLS)}
CODE = [i for i, c in enumerate(CELLS) if c['cell_type'] == 'code']


# ---------------------------------------------------------------------------------------------- execution helpers
UPLOADS = []


def install_colab_shim():
    google = types.ModuleType('google')
    colab = types.ModuleType('google.colab')
    files = types.ModuleType('google.colab.files')

    def upload():
        if not UPLOADS:
            raise RuntimeError('shim: no prepared upload')
        name, payload = UPLOADS.pop(0)
        return {name: payload}

    files.upload = upload
    colab.files = files
    google.colab = colab
    sys.modules.update({'google': google, 'google.colab': colab, 'google.colab.files': files})


def run_cell(ns, idx, overrides=None, label=None):
    src = SRC[idx]
    for old, new in (overrides or {}).items():
        assert old in src, (idx, old)
        src = src.replace(old, new)
    buf = io.StringIO()
    t0 = time.perf_counter()
    err = None
    with contextlib.redirect_stdout(buf):
        try:
            exec(compile(src, f'<cell {idx}>', 'exec'), ns)
        except BaseException as exc:  # noqa: BLE001
            err = f'{type(exc).__name__}: {exc}'
            traceback.print_exc(file=buf)
    out = buf.getvalue()
    row = {'cell': idx, 'label': label, 'ok': err is None, 'error': err, 'seconds': round(time.perf_counter() - t0, 1),
           'stdout_tail': out[-3000:]}
    print(f'[cell {idx}{" " + label if label else ""}] ok={err is None} {row["seconds"]}s {err or ""}', file=sys.__stdout__, flush=True)
    return row


# ---------------------------------------------------------------------------------------------- phase: static
if PHASE == 'static':
    p1 = {}
    p1['nbformat'] = [NB['nbformat'], NB['nbformat_minor']]
    p1['n_cells'] = len(CELLS)
    p1['code_cells'] = CODE
    p1['compile_errors'] = {}
    for i in CODE:
        try:
            compile(SRC[i], f'<cell {i}>', 'exec')
        except SyntaxError as exc:
            p1['compile_errors'][i] = str(exc)
    p1['persisted_outputs'] = sum(len(CELLS[i].get('outputs', [])) for i in CODE)
    p1['metadata_dimer'] = NB['metadata'].get('dimer')
    p1['head'] = git('rev-parse', 'HEAD')
    p1['notebook_blob_head'] = git('rev-parse', 'HEAD:tutorials/modnet_matting_colab.ipynb')
    p1['notebook_blob_recorded_run_aa26e44'] = git('rev-parse', 'aa26e44:tutorials/modnet_matting_colab.ipynb')
    p1['carried_revision'] = NB['metadata']['dimer']['generated_from']['revision']
    p1['carried_modules_changed_since_carried_revision'] = git('diff', '--stat', p1['carried_revision'], 'HEAD', '--', 'src')
    p1['literal_double_braces_in_prereq'] = '{{id, image, alpha}}' in SRC[1]
    p1['env_var_read'] = 'DIMER_NOTEBOOK_CI_PREINSTALLED' in SRC[3]
    p1['env_var_documented_in_markdown'] = any('DIMER_NOTEBOOK_CI_PREINSTALLED' in SRC[i] for i, c in enumerate(CELLS) if c['cell_type'] == 'markdown')
    md = '\n'.join(SRC[i] for i, c in enumerate(CELLS) if c['cell_type'] == 'markdown')
    lower = md.lower()
    p1['markdown_mentions'] = {k: (k in lower) for k in ('restart', 'troubleshoot', 'glossary', 'roadmap', 'how to use', 'predict', 'expected result', 'what to notice', 'look for', 'infrastructure', 'audience', 'checkpoint', 'conclusion', 're-run from section 3', 'rerun from section 3')}
    p1['run_all_paragraph_mentions_restart'] = 'restart' in SRC[0].split('**Run all:**')[1].split('**Bring Your Own Data:**')[0].lower()
    p1['byod_paragraph_minimum'] = 'at least four pairs' in SRC[0]
    p1['byod_rerun_instruction'] = 're-run from that cell' in SRC[0]
    p1['exercise_list'] = SRC[24].split('**Optional experiments')[1].split('\n')[0][:400]
    p1['figures_rendered_inline'] = any(k in SRC[i] for i in CODE for k in ('display(', 'plt.', 'imshow'))
    RESULTS['P1_static'] = p1
    save()

    # P5: BYOD split arithmetic and minimum-record contract (pure python, model-free modules only)
    sys.path.insert(0, os.path.join(WT, 'src'))
    import numpy as np
    from modnet_matting_pipeline.samples import split_dataset, render_portrait, load_byod_dataset
    from modnet_matting_pipeline.pipeline import validate_dataset, MIN_RECORDS
    p5 = {'MIN_RECORDS': MIN_RECORDS, 'by_n': {}}
    base = [render_portrait(9000 + i, size=64) for i in range(12)]
    for n in range(3, 11):
        sp = split_dataset(base[:n], seed=0)
        sizes = {k: len(v) for k, v in sp.items()}
        row = {'sizes': sizes}
        # what pipe.adapt does first with the training split (validate_dataset(train), default min_records)
        try:
            validate_dataset([{**r, 'image': np.zeros((512, 512, 3), np.uint8), 'alpha': np.full((512, 512), 0.5, np.float32)} for r in sp['train']])
            row['adapt_train_validation'] = 'accepted'
        except ValueError as exc:
            row['adapt_train_validation'] = f'rejected: {exc}'
        # what cell 15's refusal probes see with this test split (alpha*1.5 on the first + test[1:4])
        t = [{**r, 'image': np.zeros((512, 512, 3), np.uint8), 'alpha': np.full((512, 512), 0.5, np.float32)} for r in sp['test']]
        try:
            validate_dataset([{**t[0], 'alpha': t[0]['alpha'] * 2.5}, *t[1:4]])
            row['cell15_alpha_probe'] = 'accepted'
        except ValueError as exc:
            row['cell15_alpha_probe'] = f'rejected: {exc}'
        p5['by_n'][n] = row
    # invalid BYOD zip: missing pairs.csv, and a CSV naming an absent member
    zdir = os.path.join(SCRATCH, 'byod_bad')
    os.makedirs(zdir, exist_ok=True)
    bad = {}
    z1 = os.path.join(zdir, 'nocsv.zip')
    with zipfile.ZipFile(z1, 'w') as z:
        z.writestr('a.png', b'x')
    z2 = os.path.join(zdir, 'missing.zip')
    with zipfile.ZipFile(z2, 'w') as z:
        z.writestr('pairs.csv', 'id,image,alpha\n1,a.png,a_alpha.png\n')
    for name, path in (('no pairs.csv', z1), ('csv names absent member', z2)):
        try:
            load_byod_dataset(path)
            bad[name] = 'accepted'
        except (ValueError, FileNotFoundError) as exc:
            bad[name] = f'rejected: {exc}'
    p5['invalid_zips'] = bad
    RESULTS['P5_byod_minimum'] = p5
    save()
    print(json.dumps({'P1': {k: p1[k] for k in ('notebook_blob_head', 'literal_double_braces_in_prereq', 'run_all_paragraph_mentions_restart')}, 'P5': p5}, indent=1, default=str))

# ---------------------------------------------------------------------------------------------- phase: default
if PHASE == 'default':
    work = os.path.join(SCRATCH, 'work_default')
    os.makedirs(work, exist_ok=True)
    os.chdir(work)
    install_colab_shim()
    ns = {'__name__': '__main__'}
    t0 = time.perf_counter()
    rows = []
    for i in CODE:
        rows.append(run_cell(ns, i))
        RESULTS['P2_default_run'] = {'cells': rows, 'wall_s': round(time.perf_counter() - t0, 1), 'cwd': work}
        save()
        if not rows[-1]['ok']:
            break
    p2 = RESULTS['P2_default_run']
    p2['all_ok'] = all(r['ok'] for r in rows) and len(rows) == len(CODE)
    if p2['all_ok']:
        p2['comparison'] = ns['comparison']
        p2['best_epoch'] = ns['adapt_result']['best_epoch']
        p2['history_val_loss'] = [round(h['val_loss'], 4) for h in ns['adapt_result']['history']]
        p2['history_val_mad'] = [h['val']['mad'] for h in ns['adapt_result']['history']]
        p2['n_trainable'] = ns['adapt_result']['n_trainable']
        p2['reload_parity'] = ns['parity']
        p2['torch'] = ns['torch'].__version__
        p2['outputs'] = sorted(os.path.relpath(os.path.join(d, f), work) for d, _, fs in os.walk('outputs') for f in fs)
        p2['result_json_provenance_keys'] = sorted(json.load(open('outputs/modnet_matting_result.json'))['provenance'])
    save()

    if p2['all_ok']:
        # P4: the documented exercise "set TRAINABLE = 'full' and compare" -- rerun Section 6, 7, 8 with EPOCHS=1
        kept_before = ns['adapt_result']['history'][ns['adapt_result']['best_epoch']]
        p4 = {'kept_val_loss_before': round(kept_before['val_loss'], 6), 'kept_val_mad_before': kept_before['val']['mad'],
              'frozen_val_loss_original': round(ns['adapt_result']['history'][0]['val_loss'], 6)}
        p4['cells'] = [run_cell(ns, 19, {"EPOCHS = 6": "EPOCHS = 1", "TRAINABLE = 'branches'": "TRAINABLE = 'full'"}, 'exercise full')]
        if p4['cells'][-1]['ok']:
            h0 = ns['adapt_result']['history'][0]
            p4['rerun_epoch0'] = {'note': h0.get('note'), 'val_loss': round(h0['val_loss'], 6), 'val_mad': h0['val']['mad']}
            p4['epoch0_equals_previous_kept_not_frozen'] = abs(h0['val_loss'] - kept_before['val_loss']) < 1e-4
            p4['rerun_best_epoch'] = ns['adapt_result']['best_epoch']
            p4['cells'].append(run_cell(ns, 21, label='exercise eval'))
            if p4['cells'][-1]['ok']:
                p4['comparison_after_exercise'] = ns['comparison']
                p4['validation_loss_line'] = {'frozen_reported': ns['adapt_result']['history'][0]['val_loss'], 'kept': ns['best']['val_loss']}
            p4['cells'].append(run_cell(ns, 23, label='exercise export/reload'))
        RESULTS['P4_exercise_rerun'] = p4
        save()

        # P3: the BYOD instruction "re-run from that cell" (Section 4) with the same sample data: is Section 5 still frozen?
        p3 = {'adapted_test_mad_before': ns['adapted_test']['model']['mad'], 'original_frozen_test_mad': p2['comparison']['mad']['frozen']}
        p3['cells'] = [run_cell(ns, 15, label='rerun S4'), run_cell(ns, 17, label='rerun S5')]
        if all(c['ok'] for c in p3['cells']):
            p3['section5_frozen_test_after_rerun'] = ns['frozen_test']['model']
            p3['section5_evaluate_adapted_flag'] = ns['frozen_test']['adapted']
            p3['section5_reports_adapted_model_as_frozen'] = ns['frozen_test']['adapted'] is True
            p3['cells'].append(run_cell(ns, 19, label='rerun S6'))
            if p3['cells'][-1]['ok']:
                h0 = ns['adapt_result']['history'][0]
                p3['rerun_epoch0'] = {'note': h0.get('note'), 'val_loss': round(h0['val_loss'], 6), 'val_mad': h0['val']['mad']}
                p3['cells'].append(run_cell(ns, 21, label='rerun S7'))
        RESULTS['P3_rerun_from_section4'] = p3
        save()
    print(json.dumps({k: RESULTS.get(k) for k in ('P4_exercise_rerun', 'P3_rerun_from_section4')}, indent=1, default=str)[:6000])
    print(json.dumps({k: v for k, v in p2.items() if k != 'cells'}, indent=1, default=str)[:4000])

# ---------------------------------------------------------------------------------------------- phase: byod
if PHASE == 'byod':
    work = os.path.join(SCRATCH, 'work_byod')
    os.makedirs(work, exist_ok=True)
    os.chdir(work)
    install_colab_shim()
    ns = {'__name__': '__main__'}
    rows = [run_cell(ns, i) for i in CODE[:6]]  # install (skipped), 4 modules, Section 3 (fresh pipe)
    import numpy as np
    from PIL import Image
    render = ns['render_portrait']
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as z:
        lines = ['id,image,alpha']
        for k in range(6):
            r = render(7000 + k)
            img = io.BytesIO(); Image.fromarray(r['image']).resize((640, 480)).save(img, 'PNG')
            alp = io.BytesIO(); Image.fromarray(np.clip(r['alpha'] * 255 + 0.5, 0, 255).astype(np.uint8)).resize((640, 480)).save(alp, 'PNG')
            z.writestr(f'p{k}.png', img.getvalue()); z.writestr(f'p{k}_alpha.png', alp.getvalue())
            lines.append(f'u{k},p{k}.png,p{k}_alpha.png')
        z.writestr('pairs.csv', '\n'.join(lines) + '\n')
    photo = io.BytesIO(); Image.fromarray(render(7100)['image']).resize((900, 1200)).save(photo, 'JPEG')
    UPLOADS[:] = [('my_pairs.zip', buf.getvalue()), ('me.jpg', photo.getvalue())]
    rows.append(run_cell(ns, 15, {'USE_BYOD = False': 'USE_BYOD = True'}, 'BYOD 6 pairs'))
    p6 = {'cells': rows}
    if rows[-1]['ok']:
        p6['splits'] = {k: len(v) for k, v in (('train', ns['train_records']), ('validation', ns['val_records']), ('test', ns['test_records']))}
        for i, ov, lab in ((17, None, 'frozen'), (19, {'EPOCHS = 6': 'EPOCHS = 2'}, 'adapt 2 epochs'), (21, None, 'eval'),
                           (23, {'USE_BYOD_PHOTO = False': 'USE_BYOD_PHOTO = True'}, 'photo + export')):
            rows.append(run_cell(ns, i, ov, lab))
            if not rows[-1]['ok'] and lab != 'eval':  # continue past the Section 7 assertion so the photo gate and export are exercised
                break
        p6['section7_assertion_failed'] = not rows[-3]['ok'] if len(rows) >= 3 else None
        if rows[-1]['ok']:
            p6['comparison'] = ns['comparison']
            p6['photo_report'] = ns['photo_report']
            p6['reload_parity'] = ns['parity']
    RESULTS['P6_byod_six_pairs'] = p6
    save()
    print(json.dumps({k: v for k, v in p6.items() if k != 'cells'}, indent=1, default=str))
    for r in rows:
        print(r['cell'], r['label'], r['ok'], r['error'])
